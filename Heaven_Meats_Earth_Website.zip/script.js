const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
toggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
  toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
});
document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  toggle.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

// The contact form prepares an email in the visitor's email app.
// Replace the address below with the business email before publishing.
const BUSINESS_EMAIL = 'REPLACE-WITH-YOUR-BUSINESS-EMAIL';
document.getElementById('question-form').addEventListener('submit', event => {
  event.preventDefault();
  const status = document.getElementById('form-status');
  if (BUSINESS_EMAIL.startsWith('REPLACE-')) {
    status.textContent = 'The contact form is designed. Add your business email in script.js before publishing so messages reach you.';
    return;
  }
  const data = new FormData(event.currentTarget);
  const subject = encodeURIComponent(`Website inquiry: ${data.get('topic')}`);
  const body = encodeURIComponent(`Name: ${data.get('name')}\nEmail: ${data.get('email')}\nTopic: ${data.get('topic')}\n\n${data.get('message')}`);
  window.location.href = `mailto:${BUSINESS_EMAIL}?subject=${subject}&body=${body}`;
});