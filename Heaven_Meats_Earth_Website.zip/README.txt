HEAVEN MEATS EARTH WEBSITE
==========================

Files:
- index.html: website content
- styles.css: layout and styling
- script.js: mobile navigation and contact form
- assets/: your supplied circular and horizontal logos

BEFORE PUBLISHING:
1. Open script.js and replace REPLACE-WITH-YOUR-BUSINESS-EMAIL with the email address where you want customer questions sent.
2. Update any business details (phone, hours, service area, social links) when you have them.
3. The menu section is intentionally a placeholder so you can add menu items and prices later.
4. The contact form opens the visitor's email application. It does not send messages directly from the website.

CLOUDFLARE PAGES DEPLOYMENT:
1. Sign in to Cloudflare.
2. Open Workers & Pages, then Create application > Pages > Upload assets (wording may vary).
3. Upload the contents of this folder, or the ZIP contents. Make sure index.html is at the top level.
4. Deploy the site.
5. In the Pages project, open Custom domains and add heavenmeatsearth.com (and optionally www.heavenmeatsearth.com).
6. Follow Cloudflare's prompts to attach the domain.

This is a static website. Cloudflare Pages can host it without a paid website-builder subscription.
